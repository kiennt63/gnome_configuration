# WhiteSur Light ulauncher

A theme for Ulauncher. WhiteSur Light theme.

## Screenshot
![](https://i.imgur.com/PQ6hGiT.png)

## Installation

```sh
mkdir -p ~/.config/ulauncher/user-themes
git clone https://github.com/Raayib/WhiteSur-Light-ulauncher.git \
  ~/.config/ulauncher/user-themes/WhiteSur-Light-ulauncher
```
