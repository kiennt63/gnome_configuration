/*
 * material ocean
 * (c) 2020 Abubakar Yagoub <i@blacksuan19.me> (https://blacksuan19.tk)
 * under the MIT license
 */

'use strict';

module.exports = {
  id: '69e7ccb2-4aef-484c-876d-3de1b433d2b9',
  tags: ['theme', 'dark'],
  name: 'material ocean',
  desc: 'an oceanic colour palette.',
  version: '0.1.0',
  author: 'blacksuan19',
};
