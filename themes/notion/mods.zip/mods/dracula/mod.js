/*
 * dracula
 * (c) 2020 @mimishahzad386#5651
 * (c) 2020 dracula
 * under the MIT license
 */

'use strict';

module.exports = {
  id: '033bff54-50ba-4cec-bdc0-b2ca7e307086',
  tags: ['theme', 'dark'],
  name: 'dracula',
  desc:
    'a theme based on the popular dracula color palette originally by zeno rocha and friends. ',
  version: '0.1.0',
  author: 'dracula',
};
