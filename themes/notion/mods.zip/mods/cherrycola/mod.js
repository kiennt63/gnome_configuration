/*
 * cherry cola
 * (c) 2020 Alexa Baldon (https://github.com/runargs)
 * under the MIT license
 */

'use strict';

module.exports = {
  id: 'ec5c4640-68d4-4d25-aefd-62c7e9737cfb',
  tags: ['theme', 'dark'],
  name: 'cherry cola',
  desc: 'a delightfully plummy, cherry cola flavored theme.',
  version: '0.1.0',
  author: 'runargs',
};
